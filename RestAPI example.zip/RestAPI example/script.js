let temp =20;


//----------------------------------------

const express = require('express')
const app = express()
const port = 3000

app.use(express.static('public'))


//HTTP ROUTE

app.get('/currentTemp', (req, res) => {
  res.send('Current Room Temperature: '+temp)
})

app.get('/updateTemp/:temp', (req,res)=>{

let newData = req.params.temp;

temp = newData;


});


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})